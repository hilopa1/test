# ShadowTools (v2 – echte Checks + System-Specs)

OSINT- & Netzwerk-Diagnose-Toolkit mit Dark-Theme-GUI (CustomTkinter).

## Neu in dieser Version
- **Username-Suche**: jetzt echte Live-Checks gegen GitHub, GitLab, Reddit,
  Instagram, TikTok, X, Steam, Pinterest, dev.to, Medium (HTTP-Status +
  Body-Text-Prüfung statt Demo-Daten).
- **E-Mail Breach Check** (OSINT): kostenloser Check gegen die öffentliche
  XposedOrNot-Datenbank (Alternative zu HIBP, dessen E-Mail-API mittlerweile
  kostenpflichtig ist). Kein API-Key nötig.
- **Wo registriert?** (OSINT): Best-effort-Check, auf welchen bekannten
  Diensten (Gravatar, GitHub, Spotify) eine E-Mail-Adresse bereits
  registriert ist. Nutzt inoffizielle Endpunkte (ähnliches Prinzip wie das
  bekannte Open-Source-Tool "holehe") – **nur für die eigene E-Mail-Adresse
  verwenden**, nicht zur Durchleuchtung fremder Personen.
- **Find My Specs** (Network): zeigt echte Infos über das eigene Gerät –
  Benutzername, Hostname, OS, CPU, RAM, Speicher, lokale/öffentliche IP,
  MAC-Adresse, Uptime, Python-Version. Akkustatus wird automatisch nur
  angezeigt, wenn ein Akku erkannt wird (Laptop-Erkennung über `psutil`).
- **Passwort-Leak-Check** (Utilities): kostenloser, anonymer Check via HIBP
  "Pwned Passwords" (k-Anonymität – das Passwort verlässt nie im Klartext
  den Rechner, kein API-Key nötig).
- **Domain Info**: WHOIS jetzt über `python-whois` statt Platzhalter.

## Was enthalten ist
- **OSINT**: IP-Geolocation, Domain-/DNS-Info (inkl. WHOIS), Username-Suche,
  Telefonnummer-Validierung, E-Mail-Breach-Check, E-Mail-Registrierungs-Check.
- **Network**: Multi-threaded Port-Scanner, HTTP-Security-Header-Check,
  SSL/TLS-Zertifikatsinfo, Ping, Find My Specs (eigenes Gerät).
- **Utilities**: Passwort-Generator, Passwort-Leak-Check, Hash-Funktionen,
  Base64/Binär-Encoder, Caesar-Cipher, Generator für frei erfundene
  Test-/QA-Formulardaten.

## Was bewusst NICHT enthalten ist
- Kein Discord-Token-Checker, kein Message-/Webhook-Spammer.
- Kein "Anti-Detection"-Layer zur Umgehung von Plattform-Sicherheits-
  mechanismen.
- Kein Generator für angebliche Gutschein-/Gift-Codes.
- Keine Generierung von Daten, die wie echte Ausweis-/Sozialversicherungs-
  nummern aussehen.

## Installation & Start
```bash
pip install -r requirements.txt
python main.py
```

## Nutzungshinweis
- Portscanner, HTTP-Header-Check und SSL-Info nur gegen **eigene** Systeme
  oder Systeme, für die eine ausdrückliche Erlaubnis vorliegt, verwenden.
- "Wo registriert?" und Username-Suche nur für die **eigene** Identität
  nutzen, nicht um fremde Personen zu durchleuchten.
- Die inoffiziellen Endpunkte im "Wo registriert?"-Check können sich
  jederzeit ändern; ein "❓"-Ergebnis bedeutet nicht zwingend "nicht
  registriert", sondern kann auch heißen, dass der Endpunkt sich geändert
  hat.
