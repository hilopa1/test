"""
main.py
-------
ShadowTools - OSINT & Netzwerk-Diagnose-Framework (bereinigte Version)

Eigenstaendig gestaltetes, modernes Dark-UI (Akzentfarbe, Icon-Sidebar,
animierter Status-Indikator). Enthaelt bewusst KEINE Discord-Account-
Funktionen (kein Token-Checker, kein Message-Spammer, kein Webhook-
Missbrauch, kein Fake-Nitro-Generator). Gedacht fuer eigene Systeme,
eigene Domains und Lernzwecke.
"""

import os
import threading
import webbrowser
from tkinter import filedialog

import customtkinter as ctk

from modules import OSINTTools, NetworkTools, Utilities, PrivacyTools

ctk.set_appearance_mode("dark")

# ----------------------------------------------------------------- Theme
BG_APP = "#0c0f16"
BG_SIDEBAR = "#10141d"
BG_PANEL = "#141925"
BG_FIELD = "#1b2230"
ACCENT = "#7c5cff"
ACCENT_HOVER = "#6a47f0"
ACCENT_DIM = "#473a7a"
SUCCESS = "#22c55e"
WARNING = "#f59e0b"
TEXT_MAIN = "#e7e9ee"
TEXT_MUTED = "#8b93a7"
BORDER = "#232a3a"


class ShadowToolsGUI:
    NAV_ITEMS = [
        ("osint", "🛰", "OSINT"),
        ("network", "📡", "Network"),
        ("privacy", "🕵", "Privacy"),
        ("utils", "🧰", "Utilities"),
    ]

    def __init__(self):
        self.root = ctk.CTk()
        self.root.title("ShadowTools")
        self.root.geometry("1150x700")
        self.root.minsize(980, 620)
        self.root.configure(fg_color=BG_APP)

        self.osint = OSINTTools()
        self.network = NetworkTools()
        self.utils = Utilities()
        self.privacy = PrivacyTools()

        self.current_frame = None
        self.nav_buttons = {}
        self._pulse_on = True

        self.setup_ui()
        self._pulse_status_dot()

    # ============================================================ SHELL
    def setup_ui(self):
        outer = ctk.CTkFrame(self.root, fg_color=BG_APP)
        outer.pack(fill="both", expand=True)

        body = ctk.CTkFrame(outer, fg_color=BG_APP)
        body.pack(fill="both", expand=True, padx=14, pady=(14, 0))

        # ---------- Sidebar ----------
        self.sidebar = ctk.CTkFrame(body, width=210, fg_color=BG_SIDEBAR, corner_radius=14)
        self.sidebar.pack(side="left", fill="y", padx=(0, 14))
        self.sidebar.pack_propagate(False)

        brand = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        brand.pack(fill="x", pady=(22, 26), padx=18)
        ctk.CTkLabel(brand, text="◆", font=("Segoe UI", 20), text_color=ACCENT).pack(side="left")
        ctk.CTkLabel(brand, text=" ShadowTools", font=("Segoe UI Semibold", 18),
                     text_color=TEXT_MAIN).pack(side="left")

        nav_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        nav_frame.pack(fill="x", padx=12)

        for key, icon, label in self.NAV_ITEMS:
            btn = ctk.CTkButton(
                nav_frame,
                text=f"{icon}   {label}",
                anchor="w",
                font=("Segoe UI", 14),
                height=42,
                corner_radius=10,
                fg_color="transparent",
                hover_color=BG_FIELD,
                text_color=TEXT_MUTED,
                command=lambda k=key: self.navigate(k),
            )
            btn.pack(fill="x", pady=3)
            self.nav_buttons[key] = btn

        footer_note = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        footer_note.pack(side="bottom", fill="x", padx=16, pady=18)
        ctk.CTkLabel(
            footer_note,
            text="Nur für eigene Systeme\nund Lernzwecke nutzen.",
            font=("Segoe UI", 10.5),
            text_color=TEXT_MUTED,
            justify="left",
        ).pack(anchor="w")

        # ---------- Content area ----------
        right_col = ctk.CTkFrame(body, fg_color=BG_APP)
        right_col.pack(side="right", fill="both", expand=True)

        self.content = ctk.CTkFrame(right_col, fg_color=BG_APP)
        self.content.pack(fill="both", expand=True)

        # ---------- Status bar ----------
        status_bar = ctk.CTkFrame(outer, fg_color=BG_SIDEBAR, height=34, corner_radius=0)
        status_bar.pack(fill="x", side="bottom", pady=0)

        status_inner = ctk.CTkFrame(status_bar, fg_color="transparent")
        status_inner.pack(fill="x", padx=18, pady=4)

        self.status_dot = ctk.CTkLabel(status_inner, text="●", font=("Segoe UI", 12), text_color=SUCCESS)
        self.status_dot.pack(side="left")

        self.status_label = ctk.CTkLabel(status_inner, text="Bereit", font=("Segoe UI", 11),
                                          text_color=TEXT_MUTED)
        self.status_label.pack(side="left", padx=(6, 14))

        self.progress = ctk.CTkProgressBar(status_inner, height=6, progress_color=ACCENT,
                                            fg_color=BG_FIELD, mode="indeterminate")

        self.navigate("osint")

    def navigate(self, key):
        for k, btn in self.nav_buttons.items():
            if k == key:
                btn.configure(fg_color=ACCENT_DIM, text_color=TEXT_MAIN)
            else:
                btn.configure(fg_color="transparent", text_color=TEXT_MUTED)

        {"osint": self.show_osint, "network": self.show_network,
         "privacy": self.show_privacy, "utils": self.show_utilities}[key]()

    def clear_content(self):
        if self.current_frame:
            self.current_frame.destroy()
        self.current_frame = ctk.CTkFrame(self.content, fg_color=BG_APP)
        self.current_frame.pack(fill="both", expand=True)

    def page_header(self, icon, title, subtitle):
        head = ctk.CTkFrame(self.current_frame, fg_color="transparent")
        head.pack(fill="x", pady=(2, 14))
        row = ctk.CTkFrame(head, fg_color="transparent")
        row.pack(anchor="w")
        ctk.CTkLabel(row, text=icon, font=("Segoe UI", 22)).pack(side="left", padx=(0, 8))
        ctk.CTkLabel(row, text=title, font=("Segoe UI Semibold", 24), text_color=TEXT_MAIN).pack(side="left")
        ctk.CTkLabel(head, text=subtitle, font=("Segoe UI", 12), text_color=TEXT_MUTED).pack(anchor="w", pady=(2, 0))

    # ------------------------------------------------------ status/busy
    def _pulse_status_dot(self):
        self._pulse_on = not self._pulse_on
        if self.status_label.cget("text") == "Bereit":
            color = SUCCESS if self._pulse_on else "#1f6f3c"
        else:
            color = ACCENT if self._pulse_on else ACCENT_DIM
        self.status_dot.configure(text_color=color)
        self.root.after(650, self._pulse_status_dot)

    def _start_busy(self, message="Wird ausgeführt..."):
        self.status_label.configure(text=message)
        self.progress.pack(side="left", fill="x", expand=True, padx=(0, 4))
        self.progress.start()

    def _stop_busy(self, message="Bereit"):
        self.progress.stop()
        self.progress.pack_forget()
        self.status_label.configure(text=message)

    def run_async(self, target, on_done=None, busy_text="Wird ausgeführt..."):
        self._start_busy(busy_text)

        def wrapper():
            result = target()

            def finish():
                self._stop_busy()
                if on_done:
                    on_done(result)

            self.root.after(0, finish)

        threading.Thread(target=wrapper, daemon=True).start()

    # ----------------------------------------------------------- helpers
    def labeled_entry(self, parent, label, default=""):
        ctk.CTkLabel(parent, text=label, font=("Segoe UI", 12), text_color=TEXT_MUTED).pack(
            anchor="w", padx=16, pady=(14, 4)
        )
        entry = ctk.CTkEntry(parent, fg_color=BG_FIELD, border_width=0, height=36, corner_radius=8)
        if default:
            entry.insert(0, default)
        entry.pack(fill="x", padx=16)
        return entry

    def primary_button(self, parent, text, command):
        return ctk.CTkButton(
            parent, text=text, command=command, height=36, corner_radius=8,
            fg_color=ACCENT, hover_color=ACCENT_HOVER, font=("Segoe UI Semibold", 13),
        )

    def result_box(self, parent):
        box = ctk.CTkTextbox(
            parent, fg_color=BG_FIELD, corner_radius=8, border_width=0,
            font=("Consolas", 12), text_color=TEXT_MAIN,
        )
        box.pack(fill="both", expand=True, padx=16, pady=16)
        return box

    def set_text(self, widget, text):
        widget.delete("1.0", "end")
        widget.insert("end", text)

    def styled_tabs(self):
        tabs = ctk.CTkTabview(
            self.current_frame, fg_color=BG_PANEL, segmented_button_fg_color=BG_FIELD,
            segmented_button_selected_color=ACCENT, segmented_button_selected_hover_color=ACCENT_HOVER,
            segmented_button_unselected_color=BG_FIELD, corner_radius=14, border_width=1, border_color=BORDER,
        )
        tabs.pack(fill="both", expand=True)
        return tabs

    # ==================================================== OSINT TOOLS
    def show_osint(self):
        self.clear_content()
        self.page_header("🛰", "OSINT Tools", "Öffentlich zugängliche Informationen recherchieren.")
        tabs = self.styled_tabs()

        self.setup_ip_lookup(tabs.add("IP Lookup"))
        self.setup_username_search(tabs.add("Username Search"))
        self.setup_domain_info(tabs.add("Domain Info"))
        self.setup_phone_lookup(tabs.add("Phone Lookup"))
        self.setup_email_breach(tabs.add("E-Mail Breach Check"))
        self.setup_email_registration(tabs.add("Wo registriert?"))

    def setup_ip_lookup(self, parent):
        self.ip_entry = self.labeled_entry(parent, "IP-Adresse", "8.8.8.8")
        self.primary_button(parent, "Lookup", self.lookup_ip).pack(anchor="w", padx=16, pady=(12, 0))
        self.ip_result = self.result_box(parent)

    def lookup_ip(self):
        ip = self.ip_entry.get().strip()

        def task():
            return self.osint.ip_lookup(ip)

        def done(result):
            if result.get("success"):
                text = (
                    f"IP: {result['ip']}\n"
                    f"Land: {result.get('country')}\n"
                    f"Region: {result.get('region')}\n"
                    f"Stadt: {result.get('city')}\n"
                    f"ISP: {result.get('isp')}\n"
                    f"Organisation: {result.get('org')}\n"
                    f"Zeitzone: {result.get('timezone')}\n"
                    f"Proxy/VPN: {result.get('proxy')}\n"
                    f"Hosting: {result.get('hosting')}"
                )
            else:
                text = f"Fehler: {result.get('error')}"
            self.set_text(self.ip_result, text)

        self.run_async(task, done, "IP wird abgefragt...")

    def setup_username_search(self, parent):
        self.username_entry = self.labeled_entry(parent, "Username")
        self.primary_button(parent, "Suchen", self.search_username).pack(anchor="w", padx=16, pady=(12, 0))
        self.username_result = self.result_box(parent)

    def search_username(self):
        username = self.username_entry.get().strip()
        if not username:
            return

        def task():
            return self.osint.username_search(username)

        def done(result):
            text = f"Sicher gefunden ({result['total']}):\n"
            for platform, url in result["found_on"].items():
                text += f"  ✅ {platform}: {url}\n"
            if result["uncertain"]:
                text += "\nUnsicher (nicht verifizierbar):\n"
                for platform, url in result["uncertain"].items():
                    text += f"  ❓ {platform}: {url}\n"
            text += f"\n{result['note']}"
            self.set_text(self.username_result, text)

        self.run_async(task, done, "Suche läuft...")

    def setup_domain_info(self, parent):
        self.domain_entry = self.labeled_entry(parent, "Domain")
        self.primary_button(parent, "Info abrufen", self.get_domain_info).pack(anchor="w", padx=16, pady=(12, 0))
        self.domain_result = self.result_box(parent)

    def get_domain_info(self):
        domain = self.domain_entry.get().strip()
        if not domain:
            return

        def task():
            return self.osint.domain_info(domain)

        def done(result):
            text = (
                f"Domain: {result['domain']}\n"
                f"A-Records: {', '.join(result['a_records']) or '-'}\n"
                f"MX-Records: {', '.join(result['mx_records']) or '-'}\n"
                f"TXT-Records: {', '.join(result['txt_records']) or '-'}\n\n"
                f"WHOIS:\n{result['whois']}"
            )
            self.set_text(self.domain_result, text)

        self.run_async(task, done, "Domain wird abgefragt...")

    def setup_phone_lookup(self, parent):
        self.phone_entry = self.labeled_entry(parent, "Telefonnummer (mit Ländervorwahl)", "+491701234567")
        self.primary_button(parent, "Prüfen", self.lookup_phone).pack(anchor="w", padx=16, pady=(12, 0))
        self.phone_result = self.result_box(parent)

    def lookup_phone(self):
        number = self.phone_entry.get().strip()
        result = self.osint.phone_lookup(number)
        if result.get("success"):
            text = (
                f"Nummer: {result['number']}\n"
                f"Land: {result['country']}\n"
                f"Anbieter: {result['carrier']}\n"
                f"Gültig: {result['valid']}"
            )
        else:
            text = f"Fehler: {result.get('error')}"
        self.set_text(self.phone_result, text)

    def setup_email_breach(self, parent):
        ctk.CTkLabel(
            parent,
            text="Kostenloser Breach-Check über die öffentliche XposedOrNot-Datenbank\n"
                 "(Alternative zu HIBP, dessen E-Mail-API mittlerweile kostenpflichtig ist).",
            font=("Segoe UI", 12), text_color=TEXT_MUTED, justify="left",
        ).pack(anchor="w", padx=16, pady=(16, 0))
        self.breach_email_entry = self.labeled_entry(parent, "E-Mail-Adresse", "name@example.com")
        self.primary_button(parent, "Prüfen", self.check_email_breach).pack(anchor="w", padx=16, pady=(12, 0))
        self.breach_result = self.result_box(parent)

    def check_email_breach(self):
        email = self.breach_email_entry.get().strip()

        def task():
            return self.osint.email_breach_check(email)

        def done(result):
            if not result.get("success"):
                text = f"Fehler: {result.get('error')}"
            elif result.get("breached"):
                breaches = result.get("breaches") or []
                text = f"⚠️ E-Mail in {len(breaches)} Leak(s) gefunden:\n\n"
                text += "\n".join(f"  • {b}" for b in breaches)
            else:
                text = "✅ Keine bekannten Leaks für diese E-Mail-Adresse gefunden."
            self.set_text(self.breach_result, text)

        self.run_async(task, done, "Frage Breach-Datenbank ab...")

    def setup_email_registration(self, parent):
        ctk.CTkLabel(
            parent,
            text="Best-effort-Check, auf welchen bekannten Diensten eine E-Mail bereits\n"
                 "registriert ist. Nutzt inoffizielle Endpunkte – nur für deine EIGENE\n"
                 "E-Mail-Adresse verwenden, nicht um fremde Personen zu durchleuchten.",
            font=("Segoe UI", 12), text_color=TEXT_MUTED, justify="left",
        ).pack(anchor="w", padx=16, pady=(16, 0))
        self.reg_email_entry = self.labeled_entry(parent, "E-Mail-Adresse", "name@example.com")
        self.primary_button(parent, "Prüfen", self.check_email_registration).pack(anchor="w", padx=16, pady=(12, 0))
        self.reg_result = self.result_box(parent)

    def check_email_registration(self):
        email = self.reg_email_entry.get().strip()

        def task():
            return self.osint.email_registration_check(email)

        def done(result):
            if not result.get("success"):
                text = f"Fehler: {result.get('error')}"
            else:
                text = ""
                for r in result["results"]:
                    if r["registered"] is True:
                        icon = "✅"
                    elif r["registered"] is False:
                        icon = "❌"
                    else:
                        icon = "❓"
                    text += f"{icon} {r['service']}: {r['note']}\n"
                text += f"\n{result['note']}"
            self.set_text(self.reg_result, text)

        self.run_async(task, done, "Prüfe Plattformen...")

    # =================================================== NETWORK TOOLS
    def show_network(self):
        self.clear_content()
        self.page_header("📡", "Network Tools", "Diagnose für eigene/autorisierte Systeme.")
        tabs = self.styled_tabs()

        self.setup_port_scanner(tabs.add("Port Scanner"))
        self.setup_http_headers(tabs.add("HTTP Headers"))
        self.setup_ssl_info(tabs.add("SSL Info"))
        self.setup_ping(tabs.add("Ping"))
        self.setup_system_specs(tabs.add("Find My Specs"))

    def setup_port_scanner(self, parent):
        self.scan_target = self.labeled_entry(parent, "Ziel-IP/Domain (nur eigene Systeme!)")
        self.primary_button(parent, "Scan starten", self.scan_ports).pack(anchor="w", padx=16, pady=(12, 0))
        self.scan_result = self.result_box(parent)

    def scan_ports(self):
        target = self.scan_target.get().strip()
        if not target:
            return

        def task():
            return self.network.port_scan(target)

        def done(results):
            text = f"Offene Ports auf {target}:\n\n"
            for r in results:
                text += f"Port {r['port']}: {r['service']} - OFFEN\n"
            if not results:
                text += "Keine offenen Ports gefunden oder Ziel nicht erreichbar."
            self.set_text(self.scan_result, text)

        self.run_async(task, done, "Scanne Ports...")

    def setup_system_specs(self, parent):
        ctk.CTkLabel(
            parent,
            text="Echte Infos über DIESEN Rechner – nach Wichtigkeit sortiert.\n"
                 "Akkustatus wird nur angezeigt, wenn ein Akku erkannt wird (Laptop).",
            font=("Segoe UI", 12), text_color=TEXT_MUTED, justify="left",
        ).pack(anchor="w", padx=16, pady=(16, 0))
        self.primary_button(parent, "Specs abrufen", self.get_system_specs).pack(anchor="w", padx=16, pady=(12, 0))
        self.specs_result = self.result_box(parent)

    def get_system_specs(self):
        def task():
            return self.network.system_specs()

        def done(specs):
            text = "\n".join(f"{key}: {value}" for key, value in specs.items())
            self.set_text(self.specs_result, text)

        self.run_async(task, done, "Sammle Systeminfos...")

    def setup_http_headers(self, parent):
        self.header_url = self.labeled_entry(parent, "URL", "https://example.com")
        self.primary_button(parent, "Header prüfen", self.check_headers).pack(anchor="w", padx=16, pady=(12, 0))
        self.header_result = self.result_box(parent)

    def check_headers(self):
        url = self.header_url.get().strip()
        result = self.network.http_headers(url)
        if "error" not in result:
            text = f"URL: {result['url']}\nServer: {result['server']}\n\nSecurity-Header:\n"
            for header, value in result["security_headers"].items():
                text += f"  {header}: {value}\n"
        else:
            text = f"Fehler: {result['error']}"
        self.set_text(self.header_result, text)

    def setup_ssl_info(self, parent):
        self.ssl_host = self.labeled_entry(parent, "Hostname", "example.com")
        self.primary_button(parent, "SSL-Info abrufen", self.get_ssl_info).pack(anchor="w", padx=16, pady=(12, 0))
        self.ssl_result = self.result_box(parent)

    def get_ssl_info(self):
        host = self.ssl_host.get().strip()
        result = self.network.ssl_info(host)
        if result.get("success"):
            text = (
                f"SSL-Version: {result['ssl_version']}\n"
                f"Cipher: {result['cipher']}\n"
                f"Seriennummer: {result['serial_number']}\n"
                f"Gültig von: {result['not_before']}\n"
                f"Gültig bis: {result['not_after']}"
            )
        else:
            text = f"Fehler: {result.get('error')}"
        self.set_text(self.ssl_result, text)

    def setup_ping(self, parent):
        self.ping_host = self.labeled_entry(parent, "Host", "example.com")
        self.primary_button(parent, "Ping", self.do_ping).pack(anchor="w", padx=16, pady=(12, 0))
        self.ping_result = self.result_box(parent)

    def do_ping(self):
        host = self.ping_host.get().strip()
        result = self.network.ping(host)
        text = f"Host: {result['host']}\nErreichbar: {result['reachable']}\n\n{result['output']}"
        self.set_text(self.ping_result, text)

    # ===================================================== PRIVACY
    def show_privacy(self):
        self.clear_content()
        self.page_header("🕵", "Privacy Tools", "Wie sichtbar bist du im Internet?")
        tabs = self.styled_tabs()

        self.setup_reverse_image_search(tabs.add("Reverse Image Search"))

    def setup_reverse_image_search(self, parent):
        ctk.CTkLabel(
            parent,
            text="Lädt dein Foto kurz auf einen anonymen Temp-Hoster (löscht sich selbst)\n"
                 "und öffnet danach automatisch Google Images, Yandex und TinEye damit.\n"
                 "⚠ Dein Foto ist für die gewählte Dauer über einen zufälligen Link\n"
                 "öffentlich erreichbar – nur Fotos nutzen, bei denen das okay ist.",
            font=("Segoe UI", 12), text_color=TEXT_MUTED, justify="left",
        ).pack(anchor="w", padx=16, pady=(16, 0))

        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=16, pady=(14, 0))

        self.ris_path_label = ctk.CTkLabel(row, text="Kein Foto gewählt", font=("Segoe UI", 12),
                                            text_color=TEXT_MUTED)
        self.ris_path_label.pack(side="left", padx=(0, 10))

        ctk.CTkButton(
            row, text="Foto auswählen...", command=self.choose_image,
            fg_color=BG_FIELD, hover_color=ACCENT_DIM, text_color=TEXT_MAIN,
            height=32, corner_radius=8, font=("Segoe UI", 12),
        ).pack(side="left")

        opts = ctk.CTkFrame(parent, fg_color="transparent")
        opts.pack(fill="x", padx=16, pady=(12, 0))
        ctk.CTkLabel(opts, text="Löscht sich nach:", font=("Segoe UI", 12), text_color=TEXT_MUTED).pack(side="left")
        self.ris_expiry = ctk.CTkOptionMenu(
            opts, values=["1h", "12h", "24h", "72h"],
            fg_color=BG_FIELD, button_color=ACCENT, button_hover_color=ACCENT_HOVER,
        )
        self.ris_expiry.pack(side="left", padx=8)

        self.primary_button(parent, "Hochladen & Suchen starten", self.run_reverse_image_search).pack(
            anchor="w", padx=16, pady=14
        )
        self.ris_result = self.result_box(parent)
        self.selected_image_path = None

    def choose_image(self):
        path = filedialog.askopenfilename(
            title="Foto auswählen",
            filetypes=[("Bilder", "*.jpg *.jpeg *.png *.webp"), ("Alle Dateien", "*.*")],
        )
        if path:
            self.selected_image_path = path
            self.ris_path_label.configure(text=os.path.basename(path), text_color=TEXT_MAIN)

    def run_reverse_image_search(self):
        path = getattr(self, "selected_image_path", None)
        if not path:
            self.set_text(self.ris_result, "Bitte zuerst ein Foto auswählen.")
            return
        expiry = self.ris_expiry.get()

        def task():
            return self.privacy.reverse_image_search(path, expiry)

        def done(result):
            if not result.get("success"):
                self.set_text(self.ris_result, f"Fehler: {result.get('error')}")
                return

            for name, link in result["links"].items():
                webbrowser.open_new_tab(link)

            text = (
                f"✅ Hochgeladen, löscht sich nach {result['expiry']}.\n"
                f"Temp-Link: {result['hosted_url']}\n\n"
                f"Geöffnete Tabs:\n"
            )
            for name, link in result["links"].items():
                text += f"  • {name}\n"
            self.set_text(self.ris_result, text)

        self.run_async(task, done, "Lade Foto hoch und starte Suche...")

    # ===================================================== UTILITIES
    def show_utilities(self):
        self.clear_content()
        self.page_header("🧰", "Utilities", "Krypto-Helfer und Test-Datengenerierung.")
        tabs = self.styled_tabs()

        self.setup_password_gen(tabs.add("Passwort-Generator"))
        self.setup_password_pwned(tabs.add("Passwort-Leak-Check"))
        self.setup_hash_tools(tabs.add("Hash-Tools"))
        self.setup_encoders(tabs.add("Encoder"))
        self.setup_test_identity(tabs.add("Test-Daten (QA)"))

    def setup_password_gen(self, parent):
        opts = ctk.CTkFrame(parent, fg_color="transparent")
        opts.pack(fill="x", padx=16, pady=(16, 0))

        ctk.CTkLabel(opts, text="Länge", font=("Segoe UI", 12), text_color=TEXT_MUTED).pack(side="left")
        self.pwd_length = ctk.CTkEntry(opts, width=60, fg_color=BG_FIELD, border_width=0, height=32)
        self.pwd_length.insert(0, "16")
        self.pwd_length.pack(side="left", padx=8)

        self.pwd_upper_var = ctk.BooleanVar(value=True)
        self.pwd_lower_var = ctk.BooleanVar(value=True)
        self.pwd_digits_var = ctk.BooleanVar(value=True)
        self.pwd_special_var = ctk.BooleanVar(value=True)

        for text, var in (
            ("Großbuchstaben", self.pwd_upper_var), ("Kleinbuchstaben", self.pwd_lower_var),
            ("Zahlen", self.pwd_digits_var), ("Sonderzeichen", self.pwd_special_var),
        ):
            ctk.CTkCheckBox(opts, text=text, variable=var, fg_color=ACCENT,
                             hover_color=ACCENT_HOVER, font=("Segoe UI", 12)).pack(side="left", padx=8)

        self.primary_button(parent, "Generieren", self.generate_password).pack(anchor="w", padx=16, pady=14)

        self.pwd_result = ctk.CTkEntry(parent, font=("Consolas", 14), fg_color=BG_FIELD,
                                        border_width=0, height=40, corner_radius=8)
        self.pwd_result.pack(fill="x", padx=16, pady=(0, 16))

    def generate_password(self):
        try:
            length = int(self.pwd_length.get() or 16)
        except ValueError:
            length = 16

        password = self.utils.password_generator(
            length, self.pwd_upper_var.get(), self.pwd_lower_var.get(),
            self.pwd_digits_var.get(), self.pwd_special_var.get(),
        )
        self.pwd_result.delete(0, "end")
        self.pwd_result.insert(0, password)

    def setup_password_pwned(self, parent):
        ctk.CTkLabel(
            parent,
            text="Kostenloser, anonymer Check via HIBP 'Pwned Passwords' (k-Anonymität –\n"
                 "dein Passwort wird NIE im Klartext übertragen, kein API-Key nötig).",
            font=("Segoe UI", 12), text_color=TEXT_MUTED, justify="left",
        ).pack(anchor="w", padx=16, pady=(16, 0))
        self.pwned_pwd_entry = ctk.CTkEntry(parent, show="•", fg_color=BG_FIELD, border_width=0,
                                             height=36, corner_radius=8)
        self.pwned_pwd_entry.pack(fill="x", padx=16, pady=(12, 0))
        self.primary_button(parent, "Prüfen", self.check_password_pwned).pack(anchor="w", padx=16, pady=12)
        self.pwned_result = self.result_box(parent)

    def check_password_pwned(self):
        password = self.pwned_pwd_entry.get()

        def task():
            return self.utils.password_pwned_check(password)

        def done(result):
            if not result.get("success"):
                text = f"Fehler: {result.get('error')}"
            elif result.get("pwned"):
                text = f"⚠️ Dieses Passwort wurde bereits in {result['count']:,} Leak(s) gefunden!\nBitte nicht mehr verwenden."
            else:
                text = "✅ Dieses Passwort wurde in keinem bekannten Leak gefunden."
            self.set_text(self.pwned_result, text)

        self.run_async(task, done, "Prüfe gegen Leak-Datenbank...")

    def setup_hash_tools(self, parent):
        self.hash_text_entry = self.labeled_entry(parent, "Text")

        ctk.CTkLabel(parent, text="Algorithmus", font=("Segoe UI", 12), text_color=TEXT_MUTED).pack(
            anchor="w", padx=16, pady=(14, 4)
        )
        self.hash_algo = ctk.CTkOptionMenu(
            parent, values=["md5", "sha1", "sha256", "sha512"],
            fg_color=BG_FIELD, button_color=ACCENT, button_hover_color=ACCENT_HOVER,
        )
        self.hash_algo.pack(anchor="w", padx=16)

        self.primary_button(parent, "Hashen", self.do_hash).pack(anchor="w", padx=16, pady=14)

        self.hash_result = ctk.CTkEntry(parent, font=("Consolas", 12), fg_color=BG_FIELD,
                                         border_width=0, height=36, corner_radius=8)
        self.hash_result.pack(fill="x", padx=16, pady=(0, 16))

    def do_hash(self):
        text = self.hash_text_entry.get()
        algo = self.hash_algo.get()
        result = self.utils.hash_text(text, algo)
        self.hash_result.delete(0, "end")
        self.hash_result.insert(0, result.get("hash", result.get("error", "")))

    def setup_encoders(self, parent):
        self.encode_text = self.labeled_entry(parent, "Text")

        btn_frame = ctk.CTkFrame(parent, fg_color="transparent")
        btn_frame.pack(fill="x", padx=16, pady=12)

        for label, mode in (
            ("Base64 Encode", "b64e"), ("Base64 Decode", "b64d"),
            ("Zu Binär", "bin"), ("Caesar +3", "caesar"),
        ):
            ctk.CTkButton(
                btn_frame, text=label, command=lambda m=mode: self.encode(m),
                fg_color=BG_FIELD, hover_color=ACCENT_DIM, text_color=TEXT_MAIN,
                height=32, corner_radius=8, font=("Segoe UI", 12),
            ).pack(side="left", padx=(0, 6))

        self.encode_result = ctk.CTkEntry(parent, font=("Consolas", 12), fg_color=BG_FIELD,
                                           border_width=0, height=36, corner_radius=8)
        self.encode_result.pack(fill="x", padx=16, pady=(4, 16))

    def encode(self, mode):
        text = self.encode_text.get()
        if mode == "b64e":
            result = self.utils.base64_encode(text)
        elif mode == "b64d":
            result = self.utils.base64_decode(text)
        elif mode == "bin":
            result = self.utils.text_to_binary(text)
        elif mode == "caesar":
            result = self.utils.caesar_cipher(text, 3, "encrypt")
        else:
            result = ""

        self.encode_result.delete(0, "end")
        self.encode_result.insert(0, result)

    def setup_test_identity(self, parent):
        ctk.CTkLabel(
            parent,
            text="Erzeugt frei erfundene Platzhalterdaten für Formular-/QA-Tests.\n"
                 "Keine echten Personen, keine Ausweis-/Sozialversicherungsnummern.",
            font=("Segoe UI", 12), text_color=TEXT_MUTED, justify="left",
        ).pack(anchor="w", padx=16, pady=(16, 0))

        self.primary_button(parent, "Test-Identität generieren", self.generate_identity).pack(
            anchor="w", padx=16, pady=14
        )

        self.identity_result = self.result_box(parent)

    def generate_identity(self):
        identity = self.utils.fake_test_identity()
        text = (
            f"Name: {identity['name']}\n"
            f"E-Mail: {identity['email']}\n"
            f"Telefon: {identity['phone']}\n"
            f"Adresse: {identity['address']}\n"
            f"Stadt: {identity['city']}\n"
            f"PLZ: {identity['zip']}"
        )
        self.set_text(self.identity_result, text)

    # ----------------------------------------------------------- run
    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    os.makedirs("data", exist_ok=True)
    app = ShadowToolsGUI()
    app.run()
