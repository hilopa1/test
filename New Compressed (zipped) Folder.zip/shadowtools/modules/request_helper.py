"""
request_helper.py
------------------
Kleiner Wrapper um die `requests`-Bibliothek, damit alle anderen Module
(OSINT, Network) einheitliche Timeouts, Header und Fehlerbehandlung
verwenden, statt das in jeder Funktion neu zu schreiben.
"""

import requests

DEFAULT_TIMEOUT = 8
DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) ShadowTools/2.0"
}


class RequestHelper:
    """Statische Helfer-Methoden für GET/POST-Requests mit Fehlerabfangung."""

    @staticmethod
    def get(url, params=None, headers=None, timeout=DEFAULT_TIMEOUT, allow_redirects=True):
        merged_headers = {**DEFAULT_HEADERS, **(headers or {})}
        try:
            resp = requests.get(
                url, params=params, headers=merged_headers,
                timeout=timeout, allow_redirects=allow_redirects,
            )
            return resp, None
        except requests.exceptions.RequestException as exc:
            return None, str(exc)

    @staticmethod
    def post(url, data=None, json=None, headers=None, timeout=DEFAULT_TIMEOUT):
        merged_headers = {**DEFAULT_HEADERS, **(headers or {})}
        try:
            resp = requests.post(
                url, data=data, json=json, headers=merged_headers, timeout=timeout,
            )
            return resp, None
        except requests.exceptions.RequestException as exc:
            return None, str(exc)
