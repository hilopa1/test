"""
privacy_tools.py
-----------------
Tools, die zeigen, wie sichtbar man selbst im Internet ist.

- reverse_image_search : Lädt ein lokales Foto temporär zu catbox.moe
                          "Litterbox" hoch (Dateien werden dort automatisch
                          nach der gewählten Zeit gelöscht: 1h/12h/24h/72h)
                          und baut daraus fertige Rückwärts-Bildsuche-Links
                          für Google Images, Yandex und TinEye.

WICHTIG: Für die gewählte Aufbewahrungszeit ist das Foto über einen
zufälligen, nicht erratbaren Link öffentlich erreichbar (jeder mit dem
exakten Link käme dran), auch wenn es nirgendwo gelistet/indexiert wird.
Nur Fotos hochladen, bei denen das für dich okay ist. Danach löscht sich
die Datei automatisch.
"""

import os

import requests

LITTERBOX_URL = "https://litterbox.catbox.moe/resources/internals/api.php"
VALID_EXPIRIES = {"1h", "12h", "24h", "72h"}


class PrivacyTools:
    def reverse_image_search(self, image_path: str, expiry: str = "1h") -> dict:
        if not image_path or not os.path.isfile(image_path):
            return {"success": False, "error": "Datei nicht gefunden."}

        if expiry not in VALID_EXPIRIES:
            expiry = "1h"

        try:
            with open(image_path, "rb") as f:
                files = {"fileToUpload": (os.path.basename(image_path), f)}
                data = {"reqtype": "fileupload", "time": expiry}
                resp = requests.post(LITTERBOX_URL, data=data, files=files, timeout=25)
        except requests.exceptions.RequestException as exc:
            return {"success": False, "error": str(exc)}

        if resp.status_code != 200 or not resp.text.strip().startswith("http"):
            return {"success": False, "error": f"Upload fehlgeschlagen (Status {resp.status_code}: {resp.text[:120]})."}

        hosted_url = resp.text.strip()

        return {
            "success": True,
            "hosted_url": hosted_url,
            "expiry": expiry,
            "links": {
                "Google Images": f"https://www.google.com/searchbyimage?image_url={hosted_url}&client=app",
                "Yandex":        f"https://yandex.com/images/search?rpt=imageview&url={hosted_url}",
                "TinEye":        f"https://www.tineye.com/search?url={hosted_url}",
            },
        }
