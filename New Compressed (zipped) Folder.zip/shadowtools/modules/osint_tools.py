"""
osint_tools.py
--------------
Echte, funktionierende Implementierungen (keine Platzhalter/Demo-Daten):

- ip_lookup        : Geolocation via ip-api.com (kostenlos, kein Key)
- domain_info      : DNS-Records (dnspython) + WHOIS (python-whois)
- phone_lookup      : Format-/Carrier-Check via phonenumbers
- username_search   : Prüft echte Profile auf mehreren Plattformen, inkl.
                       Body-Text-Check, da viele Seiten bei "nicht gefunden"
                       trotzdem HTTP 200 liefern.
- email_breach_check : Prüft eine E-Mail gegen die kostenlose, öffentliche
                       XposedOrNot-Breach-Datenbank (kein API-Key nötig).
- email_registration_check : Best-effort-Check, auf welchen bekannten
                       Plattformen eine E-Mail-Adresse bereits registriert
                       ist (Technik wie im bekannten Open-Source-Tool
                       "holehe"). Endpunkte können sich jederzeit ändern,
                       deshalb werden Fehler einzeln abgefangen statt den
                       ganzen Check abzubrechen.

WICHTIG: Diese Checks (vor allem username_search und
email_registration_check) ausschließlich für deine eigenen Accounts /
deine eigene Identität verwenden, nicht um fremde Personen zu durchleuchten.
"""

import hashlib
import re

import dns.resolver
import phonenumbers
from phonenumbers import carrier as phone_carrier, geocoder as phone_geocoder

from .request_helper import RequestHelper

try:
    import whois as whois_lib  # python-whois
except ImportError:  # Bibliothek evtl. nicht installiert
    whois_lib = None


# ----------------------------------------------------------------- Plattformen
# Für jede Plattform: URL-Template + (optional) Text-Marker, der auf der
# Seite auftaucht, wenn der Username NICHT existiert (manche Plattformen
# liefern dafür trotzdem HTTP 200 zurück statt 404).
USERNAME_PLATFORMS = {
    "GitHub":    {"url": "https://github.com/{u}", "not_found_text": None},
    "GitLab":    {"url": "https://gitlab.com/{u}", "not_found_text": None},
    "Reddit":    {"url": "https://www.reddit.com/user/{u}/about.json", "not_found_text": None},
    "Instagram": {"url": "https://www.instagram.com/{u}/", "not_found_text": "Sorry, this page"},
    "TikTok":    {"url": "https://www.tiktok.com/@{u}", "not_found_text": "Couldn't find this account"},
    "Twitter/X": {"url": "https://x.com/{u}", "not_found_text": None},
    "Steam":     {"url": "https://steamcommunity.com/id/{u}", "not_found_text": "The specified profile could not be found"},
    "Pinterest": {"url": "https://www.pinterest.com/{u}/", "not_found_text": None},
    "dev.to":    {"url": "https://dev.to/{u}", "not_found_text": None},
    "Medium":    {"url": "https://medium.com/@{u}", "not_found_text": None},
}

NOT_FOUND_GENERIC_MARKERS = [
    "page not found", "user not found", "doesn't exist", "couldn't find",
    "konnte nicht gefunden", "404",
]


class OSINTTools:
    # ===================================================== IP LOOKUP
    def ip_lookup(self, ip: str) -> dict:
        if not ip:
            return {"success": False, "error": "Keine IP angegeben."}

        url = f"http://ip-api.com/json/{ip}"
        params = {
            "fields": "status,message,country,regionName,city,isp,org,"
                      "timezone,proxy,hosting,query"
        }
        resp, err = RequestHelper.get(url, params=params)
        if err:
            return {"success": False, "error": err}

        try:
            data = resp.json()
        except ValueError:
            return {"success": False, "error": "Ungültige Antwort vom Geolocation-Dienst."}

        if data.get("status") != "success":
            return {"success": False, "error": data.get("message", "Lookup fehlgeschlagen.")}

        return {
            "success": True,
            "ip": data.get("query", ip),
            "country": data.get("country"),
            "region": data.get("regionName"),
            "city": data.get("city"),
            "isp": data.get("isp"),
            "org": data.get("org"),
            "timezone": data.get("timezone"),
            "proxy": data.get("proxy"),
            "hosting": data.get("hosting"),
        }

    # =================================================== DOMAIN INFO
    def domain_info(self, domain: str) -> dict:
        result = {"domain": domain, "a_records": [], "mx_records": [], "txt_records": [], "whois": ""}

        for rtype, key in (("A", "a_records"), ("MX", "mx_records"), ("TXT", "txt_records")):
            try:
                answers = dns.resolver.resolve(domain, rtype, lifetime=6)
                if rtype == "MX":
                    result[key] = [str(r.exchange).rstrip(".") for r in answers]
                elif rtype == "TXT":
                    result[key] = [b"".join(r.strings).decode(errors="replace") for r in answers]
                else:
                    result[key] = [r.address for r in answers]
            except Exception:
                result[key] = []

        if whois_lib is not None:
            try:
                w = whois_lib.whois(domain)
                lines = []
                for field in ("domain_name", "registrar", "creation_date",
                               "expiration_date", "name_servers", "org", "country"):
                    value = getattr(w, field, None) if hasattr(w, field) else w.get(field)
                    if value:
                        lines.append(f"{field}: {value}")
                result["whois"] = "\n".join(lines) if lines else "Keine WHOIS-Daten gefunden."
            except Exception as exc:
                result["whois"] = f"WHOIS-Abfrage fehlgeschlagen: {exc}"
        else:
            result["whois"] = "python-whois nicht installiert (pip install python-whois)."

        return result

    # =================================================== PHONE LOOKUP
    def phone_lookup(self, number: str) -> dict:
        if not number:
            return {"success": False, "error": "Keine Nummer angegeben."}
        try:
            parsed = phonenumbers.parse(number, None)
        except phonenumbers.NumberParseException as exc:
            return {"success": False, "error": f"Konnte Nummer nicht parsen: {exc}"}

        valid = phonenumbers.is_valid_number(parsed)
        return {
            "success": True,
            "number": phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL),
            "country": phone_geocoder.description_for_number(parsed, "de") or "Unbekannt",
            "carrier": phone_carrier.name_for_number(parsed, "de") or "Unbekannt / nicht ermittelbar",
            "valid": valid,
        }

    # ================================================= USERNAME SEARCH
    def username_search(self, username: str) -> dict:
        found_on, uncertain = {}, {}

        for platform, cfg in USERNAME_PLATFORMS.items():
            url = cfg["url"].format(u=username)
            resp, err = RequestHelper.get(url, allow_redirects=True)

            if err or resp is None:
                continue

            if resp.status_code == 404:
                continue  # klar: nicht gefunden

            if resp.status_code != 200:
                # weder klar gefunden noch klar nicht gefunden
                uncertain[platform] = url
                continue

            body_lower = resp.text.lower()
            marker = cfg["not_found_text"]
            if marker and marker.lower() in body_lower:
                continue  # Seite sagt explizit "nicht gefunden"

            if any(m in body_lower for m in NOT_FOUND_GENERIC_MARKERS) and marker is None:
                # Plattform hat keinen bekannten Marker hinterlegt, aber die
                # Seite klingt nach "nicht gefunden" -> nicht sicher genug
                uncertain[platform] = url
                continue

            found_on[platform] = url

        return {
            "total": len(found_on),
            "found_on": found_on,
            "uncertain": uncertain,
            "note": (
                "Hinweis: 'Sicher gefunden' basiert auf HTTP-Status + Body-Text-Prüfung. "
                "Bei privaten Profilen oder Rate-Limiting kann ein Treffer trotzdem fehlen "
                "oder fälschlich als 'unsicher' markiert sein."
            ),
        }

    # ================================================ EMAIL BREACH CHECK
    def email_breach_check(self, email: str) -> dict:
        """Kostenloser Breach-Check über die öffentliche XposedOrNot-API
        (kein API-Key nötig). Alternative/Ergänzung zu HIBP, dessen
        Breach-API inzwischen kostenpflichtig ist."""
        if not email or "@" not in email:
            return {"success": False, "error": "Bitte eine gültige E-Mail-Adresse angeben."}

        url = f"https://api.xposedornot.com/v1/check-email/{email}"
        resp, err = RequestHelper.get(url)
        if err:
            return {"success": False, "error": err}

        if resp.status_code == 404:
            return {"success": True, "breached": False, "breaches": []}

        if resp.status_code != 200:
            return {"success": False, "error": f"API antwortete mit Status {resp.status_code}."}

        try:
            data = resp.json()
        except ValueError:
            return {"success": False, "error": "Ungültige Antwort von der Breach-API."}

        breaches = []
        raw = data.get("breaches") if isinstance(data, dict) else None
        if raw:
            for group in raw:
                if isinstance(group, list):
                    breaches.extend(group)
                else:
                    breaches.append(group)

        return {"success": True, "breached": len(breaches) > 0, "breaches": breaches}

    # ============================================ EMAIL REGISTRATION CHECK
    def email_registration_check(self, email: str) -> dict:
        """Best-effort-Check, auf welchen bekannten Diensten eine
        E-Mail-Adresse bereits registriert ist. Nutzt dieselbe Grundidee
        wie das bekannte Open-Source-Tool 'holehe': öffentliche
        Signup-/Profil-Endpunkte, die (indirekt) verraten, ob ein Account
        existiert. Diese Endpunkte sind nicht offiziell dokumentiert und
        können sich jederzeit ändern -> Fehler je Dienst werden einzeln
        abgefangen, ein Fehlschlag bei einem Dienst stoppt nicht die
        anderen Checks.

        NUR für die eigene E-Mail-Adresse verwenden.
        """
        if not email or "@" not in email:
            return {"success": False, "error": "Bitte eine gültige E-Mail-Adresse angeben."}

        results = []

        # --- Gravatar: öffentliches, offiziell unterstütztes Verfahren ---
        try:
            email_hash = hashlib.md5(email.strip().lower().encode("utf-8")).hexdigest()
            resp, err = RequestHelper.get(
                f"https://www.gravatar.com/avatar/{email_hash}", params={"d": "404"}
            )
            if err:
                results.append({"service": "Gravatar", "registered": None, "note": err})
            else:
                results.append({
                    "service": "Gravatar",
                    "registered": resp.status_code == 200,
                    "note": "Profilbild gefunden" if resp.status_code == 200 else "Kein Gravatar-Profil",
                })
        except Exception as exc:
            results.append({"service": "Gravatar", "registered": None, "note": str(exc)})

        # --- GitHub: nutzt den öffentlichen Signup-Check-Endpunkt ---
        try:
            resp, err = RequestHelper.get(
                "https://github.com/signup_check/email", params={"value": email}
            )
            if err:
                results.append({"service": "GitHub", "registered": None, "note": err})
            else:
                taken = resp.status_code == 422 or "already" in resp.text.lower() or "taken" in resp.text.lower()
                results.append({
                    "service": "GitHub",
                    "registered": taken,
                    "note": "E-Mail bereits vergeben" if taken else "Kein Treffer / Endpunkt evtl. geändert",
                })
        except Exception as exc:
            results.append({"service": "GitHub", "registered": None, "note": str(exc)})

        # --- Spotify: bekannter, inoffizieller Signup-Validierungs-Endpunkt ---
        try:
            resp, err = RequestHelper.get(
                "https://spclient.wg.spotify.com/signup/public/v1/account",
                params={"validate": 1, "email": email},
            )
            if err:
                results.append({"service": "Spotify", "registered": None, "note": err})
            else:
                try:
                    data = resp.json()
                    status = data.get("status")
                    taken = status == 20
                    results.append({
                        "service": "Spotify",
                        "registered": taken,
                        "note": "E-Mail bereits registriert" if taken else "Kein Treffer",
                    })
                except ValueError:
                    results.append({"service": "Spotify", "registered": None, "note": "Endpunkt evtl. geändert"})
        except Exception as exc:
            results.append({"service": "Spotify", "registered": None, "note": str(exc)})

        return {
            "success": True,
            "results": results,
            "note": (
                "Best-effort-Check über inoffizielle Endpunkte – kann falsch-negativ sein, "
                "wenn ein Dienst seine API geändert hat. Nur für die eigene E-Mail nutzen."
            ),
        }
