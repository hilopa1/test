"""
utilities.py
-------------
- password_generator  : Zufälliges Passwort nach gewählten Zeichenklassen.
- hash_text           : MD5/SHA1/SHA256/SHA512.
- base64_encode/_decode, text_to_binary, caesar_cipher.
- fake_test_identity  : Frei erfundene Platzhalterdaten für QA-Formulare
                        (keine echten Personen, keine Ausweisnummern).
- password_pwned_check: NEU – kostenloser Leak-Check über die HIBP
                        "Pwned Passwords"-API. Nutzt k-Anonymität: nur
                        die ersten 5 Zeichen des SHA1-Hashes werden
                        übertragen, das Passwort selbst verlässt nie
                        den Rechner im Klartext.
"""

import base64
import hashlib
import random
import secrets
import string

from .request_helper import RequestHelper

FIRST_NAMES = ["Alex", "Jamie", "Sam", "Lena", "Tom", "Nina", "Max", "Lea"]
LAST_NAMES = ["Mustermann", "Beispiel", "Test", "Platzhalter", "Fiktiv"]
CITIES = ["Beispielstadt", "Testhausen", "Musterdorf", "Fiktivburg"]
STREETS = ["Musterweg", "Teststraße", "Beispielallee", "Platzhalterring"]


class Utilities:
    # ============================================== PASSWORT-GENERATOR
    def password_generator(self, length, use_upper, use_lower, use_digits, use_special) -> str:
        pool = ""
        if use_upper:
            pool += string.ascii_uppercase
        if use_lower:
            pool += string.ascii_lowercase
        if use_digits:
            pool += string.digits
        if use_special:
            pool += "!@#$%^&*()-_=+[]{};:,.?"

        if not pool:
            return "Fehler: mindestens eine Zeichenklasse auswählen."

        length = max(1, min(length, 256))
        return "".join(secrets.choice(pool) for _ in range(length))

    # ===================================================== HASH-TOOLS
    def hash_text(self, text: str, algo: str) -> dict:
        algos = {
            "md5": hashlib.md5, "sha1": hashlib.sha1,
            "sha256": hashlib.sha256, "sha512": hashlib.sha512,
        }
        func = algos.get(algo)
        if not func:
            return {"error": f"Unbekannter Algorithmus: {algo}"}
        return {"hash": func(text.encode("utf-8")).hexdigest()}

    # ======================================================= ENCODER
    def base64_encode(self, text: str) -> str:
        return base64.b64encode(text.encode("utf-8")).decode("utf-8")

    def base64_decode(self, text: str) -> str:
        try:
            return base64.b64decode(text.encode("utf-8")).decode("utf-8")
        except Exception as exc:
            return f"Fehler: {exc}"

    def text_to_binary(self, text: str) -> str:
        return " ".join(format(byte, "08b") for byte in text.encode("utf-8"))

    def caesar_cipher(self, text: str, shift: int, mode: str = "encrypt") -> str:
        if mode == "decrypt":
            shift = -shift
        result = []
        for ch in text:
            if ch.isupper():
                result.append(chr((ord(ch) - 65 + shift) % 26 + 65))
            elif ch.islower():
                result.append(chr((ord(ch) - 97 + shift) % 26 + 97))
            else:
                result.append(ch)
        return "".join(result)

    # ================================================== TEST-IDENTITÄT
    def fake_test_identity(self) -> dict:
        first = random.choice(FIRST_NAMES)
        last = random.choice(LAST_NAMES)
        return {
            "name": f"{first} {last}",
            "email": f"{first.lower()}.{last.lower()}{random.randint(1, 999)}@example.test",
            "phone": f"+49 170 {random.randint(1000000, 9999999)}",
            "address": f"{random.choice(STREETS)} {random.randint(1, 199)}",
            "city": random.choice(CITIES),
            "zip": f"{random.randint(10000, 99999)}",
        }

    # ============================================== PASSWORT-LEAK-CHECK
    def password_pwned_check(self, password: str) -> dict:
        """Kostenloser, anonymer Check über die HIBP Pwned-Passwords-API.
        Kein API-Key nötig, das Passwort selbst wird NIE übertragen –
        nur die ersten 5 Zeichen des SHA1-Hashes (k-Anonymität)."""
        if not password:
            return {"success": False, "error": "Kein Passwort angegeben."}

        sha1 = hashlib.sha1(password.encode("utf-8")).hexdigest().upper()
        prefix, suffix = sha1[:5], sha1[5:]

        resp, err = RequestHelper.get(f"https://api.pwnedpasswords.com/range/{prefix}")
        if err:
            return {"success": False, "error": err}
        if resp.status_code != 200:
            return {"success": False, "error": f"API antwortete mit Status {resp.status_code}."}

        for line in resp.text.splitlines():
            try:
                line_suffix, count = line.split(":")
            except ValueError:
                continue
            if line_suffix.strip().upper() == suffix:
                return {"success": True, "pwned": True, "count": int(count)}

        return {"success": True, "pwned": False, "count": 0}
