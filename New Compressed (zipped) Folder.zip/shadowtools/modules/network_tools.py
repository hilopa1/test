"""
network_tools.py
-----------------
- port_scan      : Multi-threaded TCP-Connect-Scan über gängige Ports.
- http_headers   : Holt Security-relevante HTTP-Response-Header.
- ssl_info       : Liest SSL/TLS-Zertifikatsdaten eines Hosts aus.
- ping           : Plattformunabhängiger Ping-Wrapper.
- system_specs   : NEU – sammelt echte Infos über das EIGENE System
                    (Hostname, Benutzername, OS, CPU, RAM, Festplatte,
                    lokale/öffentliche IP, MAC-Adresse, Akku falls
                    vorhanden, Uptime, Python-Version), sortiert nach
                    Relevanz.

Portscanner, HTTP-Header-Check und SSL-Info nur gegen eigene Systeme oder
Systeme mit ausdrücklicher Erlaubnis verwenden.
"""

import getpass
import platform
import socket
import ssl
import subprocess
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed

from .request_helper import RequestHelper

try:
    import psutil
except ImportError:
    psutil = None

COMMON_PORTS = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
    80: "HTTP", 110: "POP3", 143: "IMAP", 443: "HTTPS", 445: "SMB",
    3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL", 6379: "Redis",
    8080: "HTTP-Alt", 8443: "HTTPS-Alt",
}

SECURITY_HEADERS = [
    "Strict-Transport-Security", "Content-Security-Policy",
    "X-Frame-Options", "X-Content-Type-Options",
    "Referrer-Policy", "Permissions-Policy",
]


class NetworkTools:
    # ===================================================== PORT SCAN
    def port_scan(self, target: str, timeout: float = 0.6) -> list:
        results = []

        def check(port):
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                    sock.settimeout(timeout)
                    if sock.connect_ex((target, port)) == 0:
                        return {"port": port, "service": COMMON_PORTS.get(port, "unbekannt")}
            except socket.error:
                return None
            return None

        with ThreadPoolExecutor(max_workers=50) as executor:
            futures = [executor.submit(check, p) for p in COMMON_PORTS]
            for future in as_completed(futures):
                res = future.result()
                if res:
                    results.append(res)

        return sorted(results, key=lambda r: r["port"])

    # =================================================== HTTP HEADERS
    def http_headers(self, url: str) -> dict:
        if not url:
            return {"error": "Keine URL angegeben."}
        if not url.startswith(("http://", "https://")):
            url = "https://" + url

        resp, err = RequestHelper.get(url)
        if err:
            return {"error": err}

        headers = resp.headers
        sec_headers = {h: headers.get(h, "❌ fehlt") for h in SECURITY_HEADERS}
        return {
            "url": url,
            "server": headers.get("Server", "unbekannt"),
            "security_headers": sec_headers,
        }

    # ====================================================== SSL INFO
    def ssl_info(self, host: str, port: int = 443) -> dict:
        if not host:
            return {"success": False, "error": "Kein Hostname angegeben."}
        try:
            context = ssl.create_default_context()
            with socket.create_connection((host, port), timeout=6) as sock:
                with context.wrap_socket(sock, server_hostname=host) as ssock:
                    cert = ssock.getpeercert()
                    return {
                        "success": True,
                        "ssl_version": ssock.version(),
                        "cipher": ssock.cipher()[0] if ssock.cipher() else "unbekannt",
                        "serial_number": cert.get("serialNumber", "unbekannt"),
                        "not_before": cert.get("notBefore", "unbekannt"),
                        "not_after": cert.get("notAfter", "unbekannt"),
                    }
        except Exception as exc:
            return {"success": False, "error": str(exc)}

    # ========================================================== PING
    def ping(self, host: str) -> dict:
        if not host:
            return {"host": host, "reachable": False, "output": "Kein Host angegeben."}

        flag = "-n" if platform.system().lower() == "windows" else "-c"
        try:
            proc = subprocess.run(
                ["ping", flag, "4", host],
                capture_output=True, text=True, timeout=10,
            )
            return {
                "host": host,
                "reachable": proc.returncode == 0,
                "output": proc.stdout or proc.stderr,
            }
        except Exception as exc:
            return {"host": host, "reachable": False, "output": str(exc)}

    # ================================================== SYSTEM SPECS
    def system_specs(self) -> dict:
        """Sammelt Infos über das EIGENE Gerät, grob nach Relevanz sortiert."""
        specs = {}

        # --- Wichtig: Identität des Geräts ---
        specs["Benutzername"] = getpass.getuser()
        specs["Hostname (PC-Name)"] = socket.gethostname()
        specs["Betriebssystem"] = f"{platform.system()} {platform.release()}"
        specs["OS-Version (Detail)"] = platform.version()
        specs["Architektur"] = platform.machine()

        # --- Netzwerk ---
        try:
            local_ip = socket.gethostbyname(socket.gethostname())
        except Exception:
            local_ip = "nicht ermittelbar"
        specs["Lokale IP"] = local_ip

        public_ip = "nicht ermittelbar (keine Internetverbindung?)"
        resp, err = RequestHelper.get("https://api.ipify.org", params={"format": "json"}, timeout=5)
        if not err and resp is not None and resp.status_code == 200:
            try:
                public_ip = resp.json().get("ip", public_ip)
            except ValueError:
                pass
        specs["Öffentliche IP"] = public_ip

        mac = uuid.getnode()
        specs["MAC-Adresse"] = ":".join(f"{(mac >> ele) & 0xff:02x}" for ele in range(40, -8, -8))

        # --- Hardware (wenn psutil verfügbar) ---
        if psutil is not None:
            specs["CPU-Kerne (logisch)"] = psutil.cpu_count(logical=True)
            specs["CPU-Auslastung"] = f"{psutil.cpu_percent(interval=0.3)} %"

            mem = psutil.virtual_memory()
            specs["RAM gesamt"] = f"{mem.total / (1024**3):.1f} GB"
            specs["RAM belegt"] = f"{mem.percent} %"

            disk = psutil.disk_usage("/")
            specs["Speicher gesamt"] = f"{disk.total / (1024**3):.1f} GB"
            specs["Speicher frei"] = f"{disk.free / (1024**3):.1f} GB"

            boot_time = psutil.boot_time()
            uptime_seconds = time.time() - boot_time
            hours, remainder = divmod(int(uptime_seconds), 3600)
            minutes = remainder // 60
            specs["Systemlaufzeit (Uptime)"] = f"{hours}h {minutes}min"

            # --- Akku: nur anzeigen, wenn überhaupt vorhanden (Laptop-Erkennung) ---
            battery = psutil.sensors_battery() if hasattr(psutil, "sensors_battery") else None
            if battery is not None:
                status = "lädt" if battery.power_plugged else "entlädt"
                specs["Akkustatus (Laptop erkannt)"] = f"{battery.percent:.0f} % ({status})"
        else:
            specs["Hinweis Hardware-Infos"] = "psutil nicht installiert (pip install psutil)"

        specs["Python-Version"] = platform.python_version()

        return specs
